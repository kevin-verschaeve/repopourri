$(document).ready(function(){
    $('body').qpScroll({
        imagesFolder: 'img',
        imagesArray: [ 'panneau-header.jpg' ],
        firstSpeed: 5,
        neighbourRatio: 1.8,
        offset: 0
    });
});
